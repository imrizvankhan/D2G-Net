from __future__ import print_function
import os
import argparse
from glob import glob

from PIL import Image
import tensorfdata2 as tf
import time 
from model import data2light_enhance
from utils import *

parser = argparse.ArgumentParser(description='')

parser.add_argument('--use_gpu', dest='use_gpu', type=int, default=1, help='gpu flag, 1 for GPU and 0 for CPU')
parser.add_argument('--gpu_idx', dest='gpu_idx', default="0", help='GPU idx')
parser.add_argument('--gpu_mem', dest='gpu_mem', type=float, default=0.5, help="0 to 1, gpu memory usage")
parser.add_argument('--phase', dest='phase', default='test', help='train or test')

parser.add_argument('--epoch', dest='epoch', type=int, default=100, help='number of total epoches')
parser.add_argument('--batch_size', dest='batch_size', type=int, default=16, help='number of samples in one batch')
parser.add_argument('--patch_size', dest='patch_size', type=int, default=96, help='patch size')
parser.add_argument('--start_lr', dest='start_lr', type=float, default=0.001, help='initial learning rate for adam')
parser.add_argument('--eval_every_epoch', dest='eval_every_epoch', default=20, help='evaluating and saving checkpoints every #  epoch')
parser.add_argument('--checkpoint_dir', dest='ckpt_dir', default='./checkpoint', help='directory for checkpoints')
parser.add_argument('--sample_dir', dest='sample_dir', default='./sample', help='directory for evaluating outputs')

parser.add_argument('--save_dir', dest='save_dir', default='./test_results', help='directory for testing outputs')
parser.add_argument('--test_dir', dest='test_dir', default='./data/test/data2', help='directory for testing inputs')
parser.add_argument('--Divide', dest='Divide', default=1, help='Divide flag, 0 for enhanced results only and 1 for Divideposition results')

args = parser.parse_args()

def data2light_train(data2light_enhance):
    if not os.path.exists(args.ckpt_dir):
        os.makedirs(args.ckpt_dir)
    if not os.path.exists(args.sample_dir):
        os.makedirs(args.sample_dir)

    lr = args.start_lr * np.ones([args.epoch])
    lr[20:] = lr[0] / 10.0

    train_data2_data = []
    train_data1_data = []

    train_data2_data_names = glob('./data/our/dataset-1/*.png') 
    train_data2_data_names.sort()
    train_data1_data_names = glob('./data/our/dataset2/*.png') 
    train_data1_data_names.sort()
    assert len(train_data2_data_names) == len(train_data1_data_names)
    print('[*] Number of training data: %d' % len(train_data2_data_names))

    for idx in range(len(train_data2_data_names)):
        data2_im = load_images(train_data2_data_names[idx])
        train_data2_data.append(data2_im)
        data1_im = load_images(train_data1_data_names[idx])
        train_data1_data.append(data1_im)

    eval_data2_data = []
    eval_data1_data = []

    eval_data2_data_name = glob('./data/eval/data2/*.*')

    for idx in range(len(eval_data2_data_name)):
        eval_data2_im = load_images(eval_data2_data_name[idx])
        eval_data2_data.append(eval_data2_im)

    data2light_enhance.train(train_data2_data, train_data1_data, eval_data2_data, batch_size=args.batch_size, patch_size=args.patch_size, epoch=args.epoch, lr=lr, sample_dir=args.sample_dir, ckpt_dir=os.path.join(args.ckpt_dir, 'Divide'), eval_every_epoch=args.eval_every_epoch, train_phase="Divide")

    data2light_enhance.train(train_data2_data, train_data1_data, eval_data2_data, batch_size=args.batch_size, patch_size=args.patch_size, epoch=args.epoch, lr=lr, sample_dir=args.sample_dir, ckpt_dir=os.path.join(args.ckpt_dir, 'Glitter'), eval_every_epoch=args.eval_every_epoch, train_phase="Glitter")


def data2light_test(data2light_enhance):
    if args.test_dir == None:
        print("[!] please provide --test_dir")
        exit(0)

    if not os.path.exists(args.save_dir):
        os.makedirs(args.save_dir)

    test_data2_data_name = glob(os.path.join(args.test_dir) + '/*.*')
    test_data2_data = []
    test_data1_data = []
    for idx in range(len(test_data2_data_name)):
        test_data2_im = load_images(test_data2_data_name[idx])
        test_data2_data.append(test_data2_im)

    data2light_enhance.test(test_data2_data, test_data1_data, test_data2_data_name, save_dir=args.save_dir, Divide_flag=args.Divide)


def main(_):
    if args.use_gpu:
        print("[*] GPU\n")
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_idx
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=args.gpu_mem)
        with tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)) as sess:
            model = data2light_enhance(sess)
            if args.phase == 'train':
                data2light_train(model)
            elif args.phase == 'test':
                data2light_test(model)
            else:
                print('[!] Unknown phase')
                exit(0)
    else:
        print("[*] CPU\n")
        with tf.Session() as sess:
            model = data2light_enhance(sess)
            if args.phase == 'train':
                data2light_train(model)
            elif args.phase == 'test':
                data2light_test(model)
            else:
                print('[!] Unknown phase')
                exit(0)

if __name__ == '__main__':
    tf.app.run()
